New-ADUser -Name "bjones" -Title "Senior Developer" -DisplayName "Brian Jones" -UserPrincipalName "bjones" -Enabled $true -AccountPassword (ConvertTo-SecureString "Demo@pass123" -AsPlainText -Force) 
New-ADUser -Name "jsmith" -Title "Senior Developer" -DisplayName "Jennifer smith" -UserPrincipalName "jsmith" -Enabled $true -AccountPassword (ConvertTo-SecureString "Demo@pass123" -AsPlainText -Force) 

$photo = [byte[]](Get-Content "C:\opsgilitytraining\bjones.jpg" -Encoding byte)            
Set-ADUser bjones -Replace @{thumbnailPhoto=$photo}

$photo = [byte[]](Get-Content "C:\opsgilitytraining\jsmith.jpg" -Encoding byte)            
Set-ADUser jsmith -Replace @{thumbnailPhoto=$photo}


New-ADUser -Name "cgreene" -Title "IT Manager" -DisplayName "Chris Green" -UserPrincipalName "cgreene" -Enabled $true -AccountPassword (ConvertTo-SecureString "Demo@pass123" -AsPlainText -Force) 
New-ADUser -Name "bandrews" -Title "IT Manager" -DisplayName "Ben Andrews" -UserPrincipalName "bandrews" -Enabled $true -AccountPassword (ConvertTo-SecureString "Demo@pass123" -AsPlainText -Force) 
New-ADUser -Name "dlongmuir" -Title "IT Manager" -DisplayName "David Longmuir" -UserPrincipalName "dlongmuir" -Enabled $true -AccountPassword (ConvertTo-SecureString "Demo@pass123" -AsPlainText -Force) 
New-ADUser -Name "ccarey" -Title "IT Manager" -DisplayName "Cynthia Carey" -UserPrincipalName "ccarey" -Enabled $true -AccountPassword (ConvertTo-SecureString "Demo@pass123" -AsPlainText -Force) 
New-ADUser -Name "mmacbeth" -Title "IT Manager" -DisplayName "Melissa MacBeth" -UserPrincipalName "mmacbeth" -Enabled $true -AccountPassword (ConvertTo-SecureString "Demo@pass123" -AsPlainText -Force) 
