﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ImageResizeWebApp.Models;
using System;

namespace ImageResizeWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ValidateAppInsightsExceptions()
        {
            try
            {
                throw new Exception("Validate Exception is caught");
            }
            catch (Exception ex)
            {
                //TODO Exercise 1: Make sure this logs to application Insights
                _logger.LogError($"Test exception thrown at {DateTime.Now} | {ex.Message}");
            }

            return RedirectToAction("Index");
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
