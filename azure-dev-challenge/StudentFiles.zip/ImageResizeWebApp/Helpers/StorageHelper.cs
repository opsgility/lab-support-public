﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using ImageResizeWebApp.Models;
using Microsoft.AspNetCore.Http;

namespace ImageResizeWebApp.Helpers
{
    public class StorageHelper
    {
        private static BlobServiceClient _blobServiceClient;

        public static bool IsImage(IFormFile file)
        {
            if (file.ContentType.Contains("image"))
            {
                return true;
            }

            string[] formats = new string[] { ".jpg", ".png", ".gif", ".jpeg" };

            return formats.Any(item => file.FileName.EndsWith(item, StringComparison.OrdinalIgnoreCase));
        }

        public static async Task<bool> UploadFileToStorage(Stream fileStream, string fileName, AzureStorageConfig _storageConfig)
        {
            // Create stoargeClient object by reading the values from the configuration (appsettings.json), passed in prebuilt
            var connectionString = $"DefaultEndpointsProtocol=https;AccountName={_storageConfig.AccountName};AccountKey={_storageConfig.AccountKey};EndpointSuffix=core.windows.net";

            //connect to the blob storage account
            _blobServiceClient = new BlobServiceClient(connectionString);

            //get the container
            var container = _blobServiceClient.GetBlobContainerClient(_storageConfig.ImageContainer);

            //get a blob client to reference the blob for upload:
            var blobClient = container.GetBlobClient(fileName);
            
            //upload the file to storage
            blobClient.Upload(fileStream, true);

            return await Task.FromResult(true);
        }

        public static async Task<List<string>> GetThumbNailUrls(AzureStorageConfig _storageConfig)
        {
            List<string> thumbnailUrls = new List<string>();

            //connect the client
            var connectionString = $"DefaultEndpointsProtocol=https;AccountName={_storageConfig.AccountName};AccountKey={_storageConfig.AccountKey};EndpointSuffix=core.windows.net";
            _blobServiceClient = new BlobServiceClient(connectionString);
            
            //get the container
            var container = _blobServiceClient.GetBlobContainerClient(_storageConfig.ThumbnailContainer);

            //iterate and get all the blobs, then add their url to the list of thumbnails
            foreach (var blob in container.GetBlobs())
            {
                //get the blob details
                var blobClient = container.GetBlobClient(blob.Name);
                //add each blob url to the list
                thumbnailUrls.Add(blobClient.Uri.ToString());
            }

            return await Task.FromResult(thumbnailUrls);
        }
    }
}
