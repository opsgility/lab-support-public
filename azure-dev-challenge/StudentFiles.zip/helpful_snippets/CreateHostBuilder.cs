public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                    webBuilder.ConfigureAppConfiguration((hostingContext, config) =>
                    {
                        var settings = config.Build();
 
                        var env = settings["Application:Environment"];
                        if (env == null || !env.Trim().Equals("develop", StringComparison.OrdinalIgnoreCase))
                        {
                            config.AddAzureAppConfiguration(options =>
                                    options.Connect(new Uri(settings["AzureAppConfigConnection"]), new ManagedIdentityCredential()));
                        }
                        else
                        {
                            config.AddAzureAppConfiguration(options =>
                                options.Connect(settings["AzureAppConfigConnection"]));
                        }
                    })
                    .UseStartup<Startup>());