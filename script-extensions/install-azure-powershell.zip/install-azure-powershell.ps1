Configuration InstallAzurePowerShell
{
    Node localhost
    {
        Script DownloadMsi
	    {
		    GetScript = {
                @{Result = "DownloadMsi"}
            }

		    TestScript = {
                if ((Test-Path "C:\Temp\azure-powershell.msi") -eq $true)
                {
                    return $true
                }
                else
                {
                    return $false
                }
            }

		    SetScript = {
			    [system.io.directory]::CreateDirectory("C:\Temp")
                # Installer copied from https://github.com/Azure/azure-powershell/releases/download/v5.6.0-March2018/azure-powershell.5.6.0.msi
                # Can't use a GitHub link, since it's a http redirect to AWS, and redirects don't work in this context	    
                $url = "https://opsgilitylabs.blob.core.windows.net/public/azure-powershell.5.6.0.msi"
                $dest = "C:\Temp\azure-powershell.msi"
			    Invoke-WebRequest $url -OutFile $dest
		    }
	    }

        Package AzurePowerShellInstall
        {
            # ProductId and Name extracted from the MSI using InstEd (www.instedit.com/)
            #  - Product ID = Tables (tab) > Property > ProductCode
            #  - Name = Tables (tab) > Property > ProductName
            Path        = "C:\Temp\azure-powershell.msi"
            ProductId   = "268C57B4-DACB-4EC2-983C-FA7BA9E0FB3F"
            Name        = "Microsoft Azure PowerShell - March 2018"
            DependsOn   = "[Script]DownloadMsi"
        }
    }
}