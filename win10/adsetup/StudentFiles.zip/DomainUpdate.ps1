[cmdletbinding()]
param(
    [parameter(ValueFromPipeline=$true)]
    [string[]]$DomainUsers=@("Vera","Beth","John","David"),
    [string]$Domain="opsaaddemo.local",
    [string]$DefaultPass="demo@pass123",
    [string]$DefaultGroup="LabUsers",
    [string]$ShareName="LabFiles",
    [string]$SharePath="C:\StudentFiles\LabFiles",
    [switch]$NoAdmin)

Begin {
    Function ConvertToDN {
        param($FQDN=$Domain)

        return ($Domain -split "\." | ForEach-Object{
            "DC=$_"
        }) -join ","
    }

    $smPassword = ConvertTo-SecureString -String $DefaultPass -AsPlainText -Force
    Remove-Variable -Name 'DefaultPass'
    
    Write-Host "Creating domain group..."
    $AdGroup = New-AdGroup -Name $DefaultGroup -GroupScope 'Global' `
        -GroupCategory 'Security' -PassThru
    If (-not $NoAdmin) { Add-AdGroupMember -Identity "Domain Admins" -Members $AdGroup  }
    Write-Host "Creating share for folder..."
    $Share = New-SmbShare -Name $ShareName -Path $SharePath -FullAccess 'Everyone' 

    $null=icacls "$SharePath" /grant "$($DefaultGroup):M"

    #Setup IT Space
    $OU = New-AdOrganizationalUnit -Name "IT" -Path (ConvertToDN) -PassThru
    $Account=New-AdUser -Name "Abbi Skinner" -SamAccountName 'AbbiS' -AccountPassword $smPassword `
        -UserPrincipalName "AbbiS@$domain" -PassThru `
        -PasswordNeverExpires $true -Path $OU.DistinguishedName
    $Account | Enable-AdAccount
    Add-AdGroupMember -Identity $AdGroup -Members $Account
}

Process {
    ForEach ($User in $DomainUsers) {
        Write-Host "Creating user [$user]..."
        $Account=New-AdUser -Name $user -SamAccountName $User -AccountPassword $smPassword `
            -UserPrincipalName "$user@$domain" -PassThru
        $Account | Enable-AdAccount
        
        Add-AdGroupMember -Identity $AdGroup -Members $Account
    }
}

End {

}