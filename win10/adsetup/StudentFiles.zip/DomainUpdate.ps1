[cmdletbinding()]
param(
    [parameter(ValueFromPipeline=$true)]
    [string[]]$DomainUsers=@("Vera","Beth","John","David"),
    [string]$Domain="opsaaddemo.local",
    [string]$DefaultPass="demo@pass123",
    [string]$DefaultGroup="LabUsers",
    [string]$ShareName="LabFiles",
    [string]$SharePath="C:\StudentFiles\LabFiles",
    [switch]$NoAdmin)

Begin {
    $smPassword = ConvertTo-SecureString -String $DefaultPass -AsPlainText -Force
    Remove-Variable -Name 'DefaultPass'
    
    Write-Host "Creating domain group..."
    $AdGroup = New-AdGroup -Name $DefaultGroup -GroupScope 'Global' `
        -GroupCategory 'Security' -PassThru
    If (-not $NoAdmin) { Add-AdGroupMember -Identity "Domain Admins" -Members $AdGroup  }
    Write-Host "Creating share for folder..."
    $Share = New-SmbShare -Name $ShareName -Path $SharePath `
        -ContinuouslyAvailable -FullAccess 'Everyone' 

    $null=icacls "$SharePath" /grant "$($DefaultGroup):M"

}

Process {
    ForEach ($User in $DomainUsers) {
        Write-Host "Creating user [$user]..."
        $User=New-AdUser -Name $user -SamAccountName $User -AccountPassword $smPassword `
            -UserPrincipalName "$user@$domain" -PassThru
        $User | Enable-AdAccount
        
        Add-AdGroupMember -Identity $AdGroup -Members $User
    }
}

End {

}