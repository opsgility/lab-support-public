Install-WindowsFeature FS-SyncShareService
md c:\marketing
New-SyncShare Marketing c:\Marketing -User Marketing
New-GPLink -Name "Work Folders" -Target "OU=Marketing,DC=OPSAADDEMO,DC=local"
New-WebBinding -Name "Default Web Site" -IP "*" -Port 443 -Protocol https
Import-Module WebAdministration
Set-Location IIS:\SslBindings
Get-ChildItem cert:\LocalMachine\MY | Where-Object {$_.Subject -match "CN=opsadsrv.opsaaddemo.local"} | Select-Object -First 1 | New-Item 0.0.0.0!443
